read me file for the mypackage
